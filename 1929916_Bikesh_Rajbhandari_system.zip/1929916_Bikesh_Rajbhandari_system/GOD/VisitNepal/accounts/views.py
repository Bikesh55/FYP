from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
from django.conf import settings
from django.core.mail import send_mail
import random
from . models import OTP
# Create your views here.


def register(request):
    if request.method == 'POST':
        """
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        """
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Username Taken')
                return redirect('register.html')
            elif User.objects.filter(email=email).exists():
                messages.info(request, 'Email Taken')
                return redirect('register.html')
            else:
                user = User.objects.create_user(username=username, first_name=first_name, last_name=last_name,
                                        password=password1, email=email)
                user.save()

                print('user created')

                #sending email after registration
                subject = "Registration Confirmed"
                message = "Your registration is confirmed."
                from_email = settings.EMAIL_HOST_USER
                to_email = user.email
                send_mail(subject, message, from_email, [to_email], fail_silently=False)

                #return redirect(request, '/login.html')
                return render(request, 'login.html')

        else:
            messages.info(request, 'Password Not Matching')
            return redirect('register.html')

        return redirect('/')

    else:
        return render(request, "register.html")



def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        #sending otp code through email
        otp = str(random.randint(1000,9999))
        shown_otps = OTP(otp=otp, user=user)
        shown_otps.save()

        subject = "Your OTP code"
        message = "Please copy and paste your OTP code" + " " + otp
        from_email = settings.EMAIL_HOST_USER
        to_email = user.email
        send_mail(subject, message,from_email, [to_email], fail_silently=False)

        # return render(request, "otp.html")


        if user is not None:
            # auth.login(request,user)
            # return redirect('travello/index')
            return redirect('otp.html')
        else:
            messages.info(request, 'Invalid Credentials')
            return redirect('login.html')

    return render(request, "login.html")


def logout(request):
    auth.logout(request)
    return redirect('login.html')


def otp_verification(request):
    if request.method == 'POST':
        otpfromhtml = request.POST['otp']
        if otpfromhtml == OTP.otp:
            return render(request, "index.html")
    return render(request, 'otp.html')


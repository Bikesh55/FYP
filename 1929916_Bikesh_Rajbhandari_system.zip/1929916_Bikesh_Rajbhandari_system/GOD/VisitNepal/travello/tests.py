from django.test import TestCase
from travello.models import Booking, Destination
# Create your tests here.


class BasicTest(TestCase):


    def test_booking(self):
        booking = Booking()
        booking.name = "Bikesh Rajbhandari"
        booking.phone_number = "9090909898"
        booking.destination = "Kathmandu"
        booking.departure = "2020-02-02"
        booking.arrival = "2020-02-04"
        booking.guide = "Ganesh"
        booking.note = "I hope I will have a quality of time."
        booking.country = "America"
        booking.number_of_people = "2"
        booking.save()

        record = Booking.objects.get(pk=1)
        self.assertEqual(record, booking)


    def test_destination(self):
        dest = Destination()
        dest.name = "Pokhara"
        dest.desc = "The queen of cities."
        dest.offer = "False"
        dest.price = "10000"
        dest.save()

        detail = Destination.objects.get(pk=1)
        self.assertEqual(detail, dest)



from django.shortcuts import render, HttpResponse, redirect
from .models import Destination, Booking, News, About, MoreDestination, BigNews
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.conf import settings
# Create your views here.


@login_required
def index(request):
    dests = Destination.objects.all()

    return render(request, 'index.html', {'dests': dests})


@login_required
def contact(request):

    return render(request, 'contact.html')


@login_required
def profile(request):

    return render(request, 'profile.html')



@login_required
def about(request):
    about = About.objects.all()

    return render(request, 'about.html', {'about': about })


@login_required
def destinations(request):
    destination =  MoreDestination.objects.all()
    return render(request, 'destinations.html', {'destination': destination})


@login_required
def elements(request):

    return render(request, 'elements.html')


@login_required
def news(request):
    news = News.objects.all()
    bignews = BigNews.objects.all()

    return render(request, 'news.html', {'news': news, 'bignews': bignews})

@login_required
def booking(request):
    if request.method == "POST":
        name = request.POST.get('name')
        phone_number = request.POST.get('phone_number')
        destination = request.POST.get('destination')
        departure = request.POST.get('departure')
        arrival = request.POST.get('arrival')
        guide = request.POST.get('guide')
        number_of_people = request.POST.get('number_of_people')
        note = request.POST.get('note')
        country = request.POST.get('country')

        book = Booking(name=name, phone_number=phone_number, destination=destination, departure=departure
                       , arrival=arrival, guide=guide, number_of_people=number_of_people, note=note,country=country)

        book.save()
        return render(request, 'list.html')

    else:

        return render(request, 'destinations.html')

@login_required
def datafromdb(request):
    all_data = Booking.objects.all()
    context ={
        'datas': all_data
    }
    return render(request, 'list.html', context)


@login_required
def rendereditform(request, id):
    edit_data = Booking.objects.get(id=id)
    context = {
        'data':edit_data
    }
    return render(request, 'edit.html', context)


@login_required
def editformdata(request, id):
    book = Booking.objects.get(id=id)
    book.name = request.POST.get('name')
    book.phone_number = request.POST.get('phone_number')
    book.destination = request.POST.get('destination')
    book.departure = request.POST.get('departure')
    book.arrival = request.POST.get('arrival')
    book.guide = request.POST.get('guide')
    book.number_of_people = request.POST.get('number_of_people')
    book.note = request.POST.get('note')
    book.country = request.POST.get('country')
    book.save()
    #return render(request, 'edit.html')
    return HttpResponse('<h1>Your data is updated </h1>')


@login_required
def deleteformdata(request, id):
    book = Booking.objects.get(id=id)
    book.delete()
    return render(request, 'list.html')


@login_required
def email(request):
    if request.method =='POST':
        email = request.POST['email']
        subject = request.POST['subject']
        message = request.POST['message']
        to = [settings.EMAIL_HOST_USER]

        send_mail(

            subject,
            message,
            email,
            [to],
            fail_silently=False
        )
        return render(request, 'contact.html', {'message': message})
    #else:
     #   return render(request, 'contact.html')



#def profile(request, id=None):
 #   book = Booking.objects.filter(user_id=id)
  #  context = {
   #     'book': book
    #}
    #return render(request, 'profile.html', context)


#def guide(request):
 #   guru = Guide.objects.all()
  #  return render(request, 'destinations.html', {'results': guru})


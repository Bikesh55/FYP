from django.urls import path
from .import views

urlpatterns = [

    path('index', views.index),
    path('contact', views.contact),
    #path('profile', views.profile),
    path('about', views.about),
    path('news', views.news),
    path('destinations', views.destinations),
    path('elements', views.elements),
    path('booking', views.booking),
    path('email', views.email),
    path('profile/<int:id>', views.profile),
    path('list', views.datafromdb),
    #path('destinations/edit/<int:id>', views.editformdata),
    path('edit/edit/<int:id>', views.editformdata),
    path('edit/<int:id>', views.rendereditform),
    path('delete/<int:id>', views.deleteformdata),

]

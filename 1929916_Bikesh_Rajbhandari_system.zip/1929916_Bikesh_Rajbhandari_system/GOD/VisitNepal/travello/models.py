from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Destination(models.Model):

    name = models.CharField(max_length=50)
    price = models.IntegerField()
    desc = models.TextField()
    img = models.ImageField(upload_to='pics')
    offer = models.BooleanField(default=False)

    def __str__(self):
        return str(self.name)



class News(models.Model):
    img = models.ImageField()
    latest_post_day = models.IntegerField()
    latest_post_month = models.CharField(max_length=10)
    latest_post_title = models.CharField(max_length= 70)
    latest_post_text = models.TextField(max_length=500)

    class Meta:
        verbose_name_plural = "News"


    def __str__(self):
        return str(self.latest_post_title)




class BigNews(models.Model):
    img = models.ImageField()
    date = models.DateField()
    news_post_title = models.CharField(max_length=50)
    news_post_text = models.TextField(max_length=500)
    news_post_category = models.CharField(max_length=100)

    class Meta:
        verbose_name_plural = "Big news"

    def __str__(self):
        return str(self.news_post_title)



class About(models.Model):
    team_img = models.ImageField()
    team_title = models.CharField(max_length=20)
    team_text = models.TextField(max_length=200)

    class Meta:
        verbose_name_plural = "About"

    def __str__(self):
        return str(self.team_title)



class MoreDestination(models.Model):
    img = models.ImageField()
    offer = models.BooleanField(default=False)
    destination_title = models.CharField(max_length=20)
    destination_subtitle = models.CharField(max_length=50)
    destination_price = models.IntegerField()

    def __str__(self):
        return str(self.destination_title)


#class Guide(models.Model):
 #   guide_name = models.CharField(max_length=50)

  #  def __str__(self):
   #     return str(self.guide_name)




class Booking(models.Model):
    #user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    #user = models.ForeignKey(User, default=None, on_delete =models.CASCADE)
    user_id = models.IntegerField(default=0)
    name = models.CharField(max_length=30)
    phone_number = models.BigIntegerField()
    destination = models.CharField(max_length=15)
    departure = models.DateField()
    arrival = models.DateField()
    #guide = models.ForeignKey(Guide , on_delete=models.CASCADE)
    guide = models.CharField(max_length=15)
    number_of_people = models.IntegerField()
    note = models.TextField(max_length=100)
    country = models.CharField(max_length=20)

    def __str__(self):
        return str(self.name)


